package com.exam.main;
import java.util.*;

class NumberFormatException extends Exception{

	public NumberFormatException(String msg) {
		super(msg);
	}
	
}

class Convert{
  String sr;
 int a;

  
public Convert() {
	super();
}
public Convert(String sr) {
	super();
	this.sr = sr;
}
  void strtoInt () throws NumberFormatException{
	  
		  int a =Integer.parseInt(sr);
		  throw new NumberFormatException("Invalid number!");
  	}
 }

  

public class Conversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Convert c= new Convert();
		Scanner sn = new Scanner(System.in);
		try {
		System.out.println("Enter a string :");
		c.sr= sn.nextLine();
		c.strtoInt();
		}
		catch(NumberFormatException e) {
			System.out.println("Exception:"+e.getMessage());
		}
		catch(NullPointerException ex) {
			System.out.println("No null values");
			
		}
		finally {
			System.out.println("Conversion attempt completed");
		}
		
		
	

}}
