package com.exam.main;
import java.util.*;


class ArithmeticException extends Exception{

	public ArithmeticException(String msg) {
		super(msg);
	}
	
	
	
}
class Student{
	int studendId;
	String name;
	double grade;
	
	
	public Student() {
		super();
	}


	public Student(int studendId, String name, double grade) {
		super();
		this.studendId = studendId;
		this.name = name;
		this.grade = grade;
	}
	
	void updateGrade(double newGrade)throws ArithmeticException {
		if (newGrade <0) {
			throw new ArithmeticException("grades can't be negative!");
		}
		else {
			newGrade=this.grade;
		}
	}


	@Override
	public String toString() {
		return "studendId=" + studendId + ", name=" + name + ", grade=" + grade ;
	}
	
	
	
}
public class Exam {

	public static void main(String[] args) throws ArithmeticException {
		// TODO Auto-generated method stub
		double newGrade;
		Scanner sn= new Scanner(System.in);
		Student s = new Student();
		System.out.println("Enter your id :");
		s.studendId= sn.nextInt();
		System.out.println("Enter your name:");
		s.name= sn.next();
		System.out.println("Enter your grades:");
		s.grade= sn.nextDouble();
		System.out.println(s.toString());
		System.out.println("Update your grade:");
		newGrade = sn.nextDouble();
		try {
			s.updateGrade(newGrade);
		}
		catch (ArithmeticException e){
			System.out.println("Exception"+e.getMessage());
			
		}
		finally {
			System.out.println("Try again");
		}
		
		

		

		
		
		
	}

}
