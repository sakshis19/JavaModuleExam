package com.exam.main;
import java.util.*;

class Patient{
	static int Uid= 101;
	int id ;
	String name;
	String diagonsis;
	int noofdays;
	
	
	public Patient() {
		super();
	}


	public Patient(int id, String name, String diagonsis, int noofdays) {
		
		this.id = Uid++;
		this.name = name;
		this.diagonsis = diagonsis;
		this.noofdays = noofdays;
	}


	@Override
	public String toString() {
		return "Patient [id=" + id + ", name=" + name + ", diagonsis=" + diagonsis + ", noofdays=" + noofdays + "]";
	}
	
}

class PatientManager{
	
	ArrayList<Patient> plist= new ArrayList<Patient>();
	Scanner sn= new Scanner(System.in);
	Patient p = new Patient();

	void addPatient(){

		System.out.println("Enter patient name:");
		p.name=sn.nextLine();
		System.out.println("Enter patient diagnosis:");
		p.diagonsis=sn.nextLine();
		System.out.println("Enter no of days of patients:");
		p.noofdays=sn.nextInt();
		plist.add(p);
		System.out.println("Patient Added Successfully with Patient Id :"+p.id);
	}
	
	void removePatient() {
		System.out.println("Enter the id to remove");
		int r= sn.nextInt();
		boolean flag=false;
		Iterator<Patient> m = plist.iterator();
		while(m.hasNext()) {
			Patient c = m.next();
			if (r==c.id) {
				flag=true;
				m.remove();
				System.out.println("Removed Successfully!");
				break;

			}
			}
		if (flag==false) {
			System.out.println("Patient not found !");
		}
	}
	
	
	void allPatient() {
		for(Patient x :plist) {
			System.out.println(x);
			
		}
	}
	
	void givenDays() {
		Patient g = new Patient();
		System.out.println("Enter the no of days:");
		int d = sn.nextInt();
		boolean flag=false;
		for (Patient j :plist) {
			if (d<g.noofdays) {
				flag=true;
				System.out.println(j);
				break;

			}
			
		}
		if(flag==false) {
			System.out.println("No Patients found!!");
			
		}
	}
}
public class Hospital {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PatientManager q = new PatientManager();
		Scanner sc = new Scanner(System.in);
		int choice;
		while(true){
		
			System.out.println("Hospital management System ---");
			System.out.println("1. Add Patient");
			System.out.println("2. Remove Patient");
			System.out.println("3. Display all patients");
			System.out.println("4. all patients admitted for more than days");
			System.out.println("5 . Exit");
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
			
			
			switch(choice) {
			case 1:{
				q.addPatient();
				break;
			}
			case 2:
			{
				q.removePatient();
				break;
				
			}
			case 3:{
				q.allPatient();
				break;
			}
			case 4:{
			
				q.givenDays();
				break;
			}
			case 5:{
				System.out.println("Exiting the system. bye bye!!");
				break;
			}
			
			}
		
		}
		
	}

}
